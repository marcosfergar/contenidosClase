function iniciarSesion() {
    let img = document.getElementById("tituloPokemon")
    let form = document.getElementById("formTrainer")
      img.style.display = 'none';   // Oculta la imagen
      form.style.display = 'block'; // Muestra el formulario
}