
function abrirPopUp() {
    window.open('../static/img/index/Tabla-tipos.jpg', 'popup', 'width=669,height=491');
}
